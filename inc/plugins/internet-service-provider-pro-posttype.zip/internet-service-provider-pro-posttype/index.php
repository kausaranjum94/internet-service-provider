<?php
/*
 Plugin Name:Internet Service Provider Pro Posttype
 lugin URI: https://www.vwthemes.com/
 short_Description: Creating new post type forInternet Service Provider Pro Theme.
 Author: VW Themes
 Version: 0.0.1
 Author URI: https://www.vwthemes.com/
*/

define( 'internet_service_provider_pro_POSTTYPE_VERSION', '1.1' );

add_action( 'init', 'internet_service_provider_pro_posttype_create_custom_post_type' );


function internet_service_provider_pro_posttype_create_custom_post_type() {

  register_post_type( 'testimonials',
    array(
  		'labels' => array(
  			'name' => __( 'Testimonials','internet-service-provider-pro-posttype' ),
  			'singular_name' => __( 'Testimonials','internet-service-provider-pro-posttype' )
  		),
  		'capability_type' => 'post',
  		'menu_icon'  => 'dashicons-businessman',
  		'public' => true,
  		'supports' => array(
  			'title',
  			'editor',
  			'thumbnail'
  		)
		)
	);

  register_post_type( 'services',
    array(
  		'labels' => array(
  			'name' => __( 'Services','internet-service-provider-pro-posttype' ),
  			'singular_name' => __( 'Services','internet-service-provider-pro-posttype' )
  		),
  		'capability_type' => 'post',
  		'menu_icon'  => 'dashicons-businessman',
  		'public' => true,
  		'supports' => array(
  			'title',
  			'editor',
  			'thumbnail'
  		)
		)
	);

}

function internet_service_provider_pro_enqueue_admin_scripts($hook) {
    global $post;

    // Only load on testimonial edit/add screens
    if ( $hook == 'post.php' || $hook == 'post-new.php' ) {
        if ( isset($post) && $post->post_type === 'testimonials' ) {
            wp_enqueue_media(); // required for image uploader

            wp_enqueue_script(
                'internet-service-provider-pro-testimonial-js',
                plugin_dir_url(__FILE__) . '/testimonial-admin.js', 
                array('jquery'), // dependencies
                '1.0.0',
                true // load in footer
            );
        }
    }

    if(($hook === 'post.php' || $hook === 'post-new.php') && isset($post->post_type) && $post->post_type === 'services') {
        wp_enqueue_media();
        wp_enqueue_script(
            'internet-service-meta',
            plugin_dir_url(__FILE__) . '/service-meta.js', 
            array('jquery'),
            null,
            true
        );
    }
}
add_action('admin_enqueue_scripts', 'internet_service_provider_pro_enqueue_admin_scripts');


// Testimonial
function internet_service_provider_pro_posttype_bn_testimonial_meta_box() {
  add_meta_box( 'internet-service-provider-pro-posttype-testimonial-meta', __( 'Enter Details', 'internet-service-provider-pro-posttype' ), 'internet_service_provider_pro_posttype_bn_testimonial_meta_callback', 'testimonials', 'normal', 'high' );
}
// Hook things in for admin
if (is_admin()){
    add_action('admin_menu', 'internet_service_provider_pro_posttype_bn_testimonial_meta_box');
}

/* Adds a meta box for custom post */
function internet_service_provider_pro_posttype_bn_testimonial_meta_callback( $post ) {
  wp_nonce_field( basename( __FILE__ ), 'internet_service_provider_pro_posttype_testimonial_meta_nonce' );
  $bn_stored_meta = get_post_meta( $post->ID );
  $testimonial_location = get_post_meta( $post->ID, 'internet_service_provider_pro_posttype_testimonial_location', true );
  $internet_service_provider_pro_posttype_star_review = get_post_meta( $post->ID, 'internet_service_provider_pro_posttype_star_review', true );
  ?>
  <div id="testimonials_custom_stuff">
    <table id="list">
      <tbody id="the-list" data-wp-lists="list:meta">
       
        <?php
          $image_2 = get_post_meta( $post->ID, 'internet_service_provider_pro_posttype_testimonial_image_2', true );
          $video_url = get_post_meta( $post->ID, 'internet_service_provider_pro_posttype_testimonial_video_url', true );
          ?>

          <tr>
            <td class="left"><?php _e( 'Second Image', 'internet-service-provider-pro-posttype' ); ?></td>
            <td class="left">
              <input type="text" name="internet_service_provider_pro_posttype_testimonial_image_2" id="internet_service_provider_pro_posttype_testimonial_image_2" value="<?php echo esc_url( $image_2 ); ?>" />
              <input type="button" class="button upload_image_button" value="Upload Image" />
            </td>
          </tr>

          <tr>
            <td class="left"><?php _e( 'Video URL', 'internet-service-provider-pro-posttype' ); ?></td>
            <td class="left">
              <input type="text" name="internet_service_provider_pro_posttype_testimonial_video_url" id="internet_service_provider_pro_posttype_testimonial_video_url" value="<?php echo esc_url( $video_url ); ?>" />
            </td>
          </tr>

        
      </tbody>
    </table>
  </div>
  <?php
}

/* Saves the custom meta input */
function internet_service_provider_pro_posttype_bn_testimomials_metadesig_save( $post_id ) {
  if (!isset($_POST['internet_service_provider_pro_posttype_testimonial_meta_nonce']) || !wp_verify_nonce($_POST['internet_service_provider_pro_posttype_testimonial_meta_nonce'], basename(__FILE__))) {
    return;
  }

  if (!current_user_can('edit_post', $post_id)) {
    return;
  }

  if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
    return;
  }

  // Save second image
  if( isset( $_POST[ 'internet_service_provider_pro_posttype_testimonial_image_2' ] ) ) {
    update_post_meta( $post_id, 'internet_service_provider_pro_posttype_testimonial_image_2', esc_url_raw( $_POST[ 'internet_service_provider_pro_posttype_testimonial_image_2' ] ) );
  }

  // Save video URL
  if( isset( $_POST[ 'internet_service_provider_pro_posttype_testimonial_video_url' ] ) ) {
    update_post_meta( $post_id, 'internet_service_provider_pro_posttype_testimonial_video_url', esc_url_raw( $_POST[ 'internet_service_provider_pro_posttype_testimonial_video_url' ] ) );
  }

}

add_action( 'save_post', 'internet_service_provider_pro_posttype_bn_testimomials_metadesig_save' );

/* ------------- Services --------------- */


function internet_service_add_meta_boxes() {
    add_meta_box(
        'internet_service_details',
        esc_html__('Service Details', 'internet-service-provider-pro-posttype'),
        'internet_service_meta_box_callback',
        'services',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'internet_service_add_meta_boxes');

function internet_service_meta_box_callback($post) {
    $price_text    = get_post_meta($post->ID, '_price_text', true);
    $price = get_post_meta($post->ID, '_price', true);
    $desc     = get_post_meta($post->ID, '_short_description', true);
    $bg       = get_post_meta($post->ID, '_background_style', true);
    $images   = get_post_meta($post->ID, '_customer_images', true); // comma-separated IDs

    ?>
    <p>
        <label for="price_text"><?php echo esc_html__('Price Text:', 'internet-service-provider-pro-posttype'); ?></label><br>
        <input type="text" id="price_text" name="price_text" value="<?php echo esc_attr($price_text); ?>" style="width:100%;">
    </p>
    <p>
        <label for="price"><?php echo esc_html__('price:', 'internet-service-provider-pro-posttype'); ?></label><br>
        <input type="text" id="price" name="price" value="<?php echo esc_attr($price); ?>" style="width:100%;">
    </p>
    <p>
        <label for="short_description"><?php echo esc_html__('Short Description:', 'internet-service-provider-pro-posttype'); ?></label><br>
        <textarea id="short_description" name="short_description" style="width:100%;"><?php echo esc_textarea($desc); ?></textarea>
    </p>
    <p>
        <label for="background_style"><?php echo esc_html__('Background Style:', 'internet-service-provider-pro-posttype'); ?></label><br>
        <select id="background_style" name="background_style">
            <option value="dark" <?php selected($bg, 'dark'); ?>><?php echo esc_html__('Dark', 'internet-service-provider-pro-posttype'); ?></option>
            <option value="light" <?php selected($bg, 'light'); ?>><?php echo esc_html__('Light', 'internet-service-provider-pro-posttype'); ?></option>
        </select>
    </p>
    <p>
        <label><?php echo esc_html__('Customer Images:', 'internet-service-provider-pro-posttype'); ?></label><br>
        <input type="hidden" id="customer_images" name="customer_images" value="<?php echo esc_attr($images); ?>">
        <button type="button" class="button" id="customer_images_button"><?php echo esc_html__('Select Images', 'internet-service-provider-pro-posttype'); ?></button>
        <div id="customer_images_preview">
            <?php 
            if($images){
                $ids = explode(',', $images);
                foreach($ids as $id){
                    echo wp_get_attachment_image((int) $id, 'thumbnail');
                }
            }
            ?>
        </div>
    </p>
    <?php
}

function internet_service_save_meta($post_id) {
    if (isset($_POST['price_text'])) {
        update_post_meta($post_id, '_price_text', sanitize_text_field($_POST['price_text']));
    }
    if (isset($_POST['price'])) {
        update_post_meta($post_id, '_price', sanitize_text_field($_POST['price']));
    }
    if (isset($_POST['short_description'])) {
        update_post_meta($post_id, '_short_description', sanitize_textarea_field($_POST['short_description']));
    }
    if (isset($_POST['background_style'])) {
        update_post_meta($post_id, '_background_style', sanitize_text_field($_POST['background_style']));
    }
    if (isset($_POST['customer_images'])) {
        update_post_meta($post_id, '_customer_images', sanitize_text_field($_POST['customer_images']));
    }
}
add_action('save_post', 'internet_service_save_meta');
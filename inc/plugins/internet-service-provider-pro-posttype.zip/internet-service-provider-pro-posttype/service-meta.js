jQuery(document).ready(function($){
    var frame;
    $('#customer_images_button').on('click', function(e){
        e.preventDefault();
        if(frame){ frame.open(); return; }
        frame = wp.media({
            title: 'Select Customer Images',
            button: { text: 'Use these images' },
            multiple: true
        });
        frame.on('select', function(){
            var ids = [];
            var preview = $('#customer_images_preview').empty();
            frame.state().get('selection').each(function(attachment){
                ids.push(attachment.id);
                preview.append('<img src="'+attachment.attributes.url+'" style="max-width:80px; margin:5px;">');
            });
            $('#customer_images').val(ids.join(','));
        });
        frame.open();
    });
});
